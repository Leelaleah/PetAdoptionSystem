import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css'; // Make sure to import your CSS file

const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="landing-page">
      <nav className="navbar">
        <div className="navbar-container">
          <div className="navbar-logo">
            <span className="logo-text">Pawfect Match</span>
          </div>
          <ul className="nav-menu">
            <li className="nav-item">
              <button className="nav-links" onClick={() => navigate('/Loginn')}>
                Login
              </button>
            </li>
            <li className="nav-item">
              <button className="nav-links nav-links-register" onClick={() => navigate('/Register')}>
                Register
              </button>
            </li>
          </ul>
        </div>
      </nav>

      <header className="hero">
        <div className="hero-content">
          <h1 className="hero-title">Find Your Furry Friend Today</h1>
          <p className="hero-subtitle">
            Adopt a pet and give them a forever home. Browse through our adorable animals
            and find your perfect companion.
          </p>
          
        </div>
      </header>

      <section className="features">
        <div className="features-container">
          <div className="feature-item">
            <i className="fas fa-paw feature-icon"></i>
            <h3>Easy Adoption Process</h3>
            <p>Our process is simple and straightforward. Find your pet in just a few clicks.</p>
          </div>
          <div className="feature-item">
            <i className="fas fa-heart feature-icon"></i>
            <h3>Support & Care</h3>
            <p>We provide all the support you need to ensure a smooth transition for your new pet.</p>
          </div>
          <div className="feature-item">
            <i className="fas fa-home feature-icon"></i>
            <h3>Forever Homes</h3>
            <p>Help us in our mission to provide loving homes to animals in need.</p>
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="footer-container">
          <p>&copy; {new Date().getFullYear()} Pawfect Match. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Home;