import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import toast from "react-hot-toast";
import { UserContext } from "../../UserContext";

const Loginn = () => {
  const [credentials, setCredentials] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { setUser } = useContext(UserContext);

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
    setError(""); // Clear error on input change
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Client-side validation
    if (!credentials.username.trim()) {
      setError("Username is required.");
      return;
    }

    if (!credentials.password.trim()) {
      setError("Password is required.");
      return;
    }

    // Basic password complexity (example)
    if (credentials.password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:1414/users/login", credentials,);
      console.log(response);
      const token = response.data.jwtToken;

      localStorage.setItem("userToken", token);
      localStorage.setItem("role", response.data.role);
      setUser(response.data);

      toast.success("Login Successful!");
      const role = localStorage.getItem("role");
      {
        role === "ROLE_USER" ? navigate("/landing") : navigate("/landingAdmin");
      }
    } catch (error) {
      toast.error("Invalid username or password. Please try again.");
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-100" style={{
      backgroundImage: `url('https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      minHeight: '100vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center'
    }}>
      <div className="card" style={{ width: "30rem", backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
        <div className="card-body">
          <h2 className="card-title text-center">Login</h2>
          {error && <p className="text-danger text-center">{error}</p>}
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label"></label>
              <input
                type="text"
                name="username"
                placeholder="Username"
                className="form-control"
                value={credentials.username}
                onChange={handleChange}
              />
            </div>
            <div className="mb-3">
              <label className="form-label"></label>
              <input
                type="password"
                name="password"
                placeholder="Password"
                className="form-control"
                value={credentials.password}
                onChange={handleChange}
              />
            </div>
            <button type="submit" className="btn btn-primary w-100">Login</button>
          </form>
          <p className="text-center mt-3">
            Don't have an account? <Link to="/register">Register here</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Loginn;