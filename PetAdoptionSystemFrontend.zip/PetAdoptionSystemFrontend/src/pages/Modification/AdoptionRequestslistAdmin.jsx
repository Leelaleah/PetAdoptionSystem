import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Table, Button } from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import "../Modification/AdoptionRequestsListAdmin.css"
import toast from 'react-hot-toast';

const AdoptionRequestsListAdmin = () => {
  
  const { petId } = useParams();
  const [adoptionRequests, setAdoptionRequests] = useState([]);
  const token = localStorage.getItem("userToken")

  useEffect(() => {
    if (petId) {
      axios.get(`http://localhost:1414/adoption-requests`,{
        headers:{
          "Authorization":`Bearer ${token}`
        }
      })
        .then(response => {
          setAdoptionRequests(response.data);
        })
        .catch(error => console.error('Error fetching adoption requests:', error));
         // Notify user if no pets found


    }
  }, [petId]);

  const handleAccept = (requestId) => {
    axios.put(`http://localhost:1414/adoption-requests/status/${requestId}`, { status: 'Accepted' },{
      headers:{
        "Authorization":`Bearer ${token}`
      }
    })
      .then(response => {
        setAdoptionRequests(prevRequests =>
          prevRequests.filter(request => request.id !== requestId)
        );
      })
      .catch(error => console.error('Error accepting adoption request:', error));
      // Notify user if no pets found

  };

  const handleDecline = (requestId) => {
    axios.put(`http://localhost:1414/adoption-requests/status/${requestId}`, { status: 'Declined' },{
      headers:{
        "Authorization":`Bearer ${token}`
      }
    })
      .then(response => {
        setAdoptionRequests(prevRequests =>
          prevRequests.filter(request => request.id !== requestId)
        );
      })
      .catch(error => console.error('Error declining adoption request:', error));
  };

  if (!petId) return <div>No pet ID provided.</div>;

  return (
    <div>
      <h2 className="my-4">Adoption Requests</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>About Yourself</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {adoptionRequests.map((request, index) => (
            <tr key={index}>
              <td>{request.id}</td>
              <td>{request.firstname}</td>
              <td>{request.lastname}</td>
              <td>{request.email}</td>
              <td>{request.phoneNumber}</td>
              <td>{request.aboutYourself}</td>
              <td>
                <Button variant="success" size="sm" onClick={() => handleAccept(request.id)}>
                  Accept
                </Button>{' '}
                <Button variant="danger" size="sm" onClick={() => handleDecline(request.id)}>
                  Decline
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default AdoptionRequestsListAdmin;
