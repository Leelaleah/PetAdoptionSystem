import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { Navbar, Nav, Modal, Button } from 'react-bootstrap';
import AdoptionRequestForm from '../Landing/AdoptionRequestForm';
import AdoptionRequestsList from '../Landing/AdoptionRequestsList';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';
import "../Modification/LandingAdmin.css"
import { UserContext } from '../../UserContext';
import toast from 'react-hot-toast';

const LandingAdmin = () => {
  const [pets, setPets] = useState([]);
  const [search, setSearch] = useState("");
  const [selectedPet, setSelectedPet] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showRequests, setShowRequests] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [petToDelete, setPetToDelete] = useState(null);

  const navigate = useNavigate();
  const {user} = useContext(UserContext)
  const token = localStorage.getItem("userToken")

  useEffect(() => {
    axios.get('http://localhost:1414/pets',{
      headers:{
        "Authorization":`Bearer ${token}`
      }
    })
      .then(response => {
        console.log("API Response:", response.data);
        setPets(response.data || []);
      })
      .catch(error => console.error('Error fetching pet data:', error));

  }, []);

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleDetailsClick = (pet) => {
    setSelectedPet(pet);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedPet(null);
  };

  const handleRequestsClick = (petId) => {
    //setShowRequests(true);
    navigate(`/adoptionrequests/${petId}`);
  };

  const handleEditClick = () => {
    navigate("/addpet");
  };

  const handleUpdateClick = (petId) => {
    navigate(`/updatepet/${petId}`);
  };

  const handleDeleteClick = (petId) => {
    setPetToDelete(petId);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    axios.delete(`http://localhost:1414/pets/${petToDelete}`,{
      headers:{
        "Authorization":`Bearer ${token}`
      }
    })
      .then(response => {
        if (response.status === 200) {
          setPets(prevPets => prevPets.filter(pet => pet.id !== petToDelete));
        } else {
          console.error('Failed to delete the pet');
        }
        setShowDeleteModal(false);
      })
      .catch(error => console.error('Error deleting pet:', error));
      toast.error("Error deleting pet."); // Notify user if no pets found

  };

  const handleClick = (e) => {
    e.preventDefault();
    navigate("/landingAdmin");
    window.location.reload();
  };

  const filteredPets = pets.filter(pet => 
    pet.breed.toLowerCase().includes(search.toLowerCase())
  );

  const handleLogoutClick = () => {
    // Perform any necessary logout actions (e.g., clearing tokens)
    navigate("/"); // Redirect to the landing page
  };

  return (
    <div>
      <Navbar bg="light" expand="lg" className="mb-4">
        <Navbar.Brand onClick={handleClick}>Pawfect</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ml-auto">
            <Button variant="outline-primary" onClick={() => handleRequestsClick(pets.id)}>Requests</Button>
            <Button variant="outline-secondary" onClick={handleEditClick}>Add Pet</Button>
            <Button variant="danger" onClick={handleLogoutClick}>Logout</Button> {/* Red logout button */}
          </Nav>
        </Navbar.Collapse>
      </Navbar>

      <div className="container">
        <h2 className="my-4">All Pets</h2>
        {!showForm && !showRequests && (
          <>
            <input
              type="text"
              className="form-control mb-4"
              placeholder="Search by breed"
              value={search}
              onChange={handleSearchChange}
            />
            <div className="row">
              {filteredPets.map((pet, index) => (
                <div key={index} className="col-md-4 mb-4">
                  <div className="card h-100">
                    <img src={pet.petImage} alt="Pet Image" className="card-img-top" />
                    <div className="card-body">
                      <h5 className="card-title">{pet.name}</h5>
                      <p className="card-text">
                        <small className="text-muted">{pet.breed} | {pet.type}</small><br />
                        <small className="text-muted">Age: {pet.age}</small><br />
                        <small className="text-muted">Price: {pet.price}</small>
                      </p>
                      <div className="d-flex justify-content-between">
                        <Button variant="warning" size="sm" onClick={() => handleUpdateClick(pet.id)}>Update</Button>
                        <Button variant="danger" size="sm" onClick={() => handleDeleteClick(pet.id)}>Delete</Button>
                        <Button variant="secondary" size="sm" onClick={() => handleDetailsClick(pet)}>Details</Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {showForm && (
          <AdoptionRequestForm />
        )}

        {showRequests && (
          <AdoptionRequestsList userId={user.id} />
        )}

        {selectedPet && (
          <Modal show={showModal} onHide={handleCloseModal}>
            <Modal.Header closeButton>
              <Modal.Title>{selectedPet.name}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <img src={selectedPet.petImage} alt="Pet Image" className="card-img-top" />
              <p><strong>Breed:</strong> {selectedPet.breed}</p>
              <p><strong>Type:</strong> {selectedPet.type}</p>
              <p><strong>Age:</strong> {selectedPet.age}</p>
              <p><strong>Price:</strong> {selectedPet.price}</p>
              <p><strong>More About {selectedPet.name}:</strong> {selectedPet.description}</p>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleCloseModal}>Close</Button>
            </Modal.Footer>
          </Modal>
        )}

        <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Confirm Delete</Modal.Title>
          </Modal.Header>
          <Modal.Body>Are you sure you want to delete this pet?</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={confirmDelete}>
              Delete
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </div>
  );
}

export default LandingAdmin;
