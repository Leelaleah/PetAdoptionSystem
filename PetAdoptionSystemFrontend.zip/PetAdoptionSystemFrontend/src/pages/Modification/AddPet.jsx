import React, { useState } from 'react';
import axios from 'axios';
import { Form, Button, Container, Navbar } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

const AddPet = () => {
  const [petDetails, setPetDetails] = useState({
    name: '',
    breed: '',
    type: 'Dog',
    age: '',
    isAdopted: false,
    price: '',
    description: '',
    petImage: ''
  });
  const [error, setError] = useState(""); // Add error state
  const navigate = useNavigate();
  const token = localStorage.getItem("userToken");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPetDetails({
      ...petDetails,
      [name]: value
    });
    setError(""); // Clear error on input change
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Client-side validation
    if (!petDetails.name.trim()) {
      setError("Pet name is required.");
      return;
    }
    if (!petDetails.breed.trim()) {
      setError("Pet breed is required.");
      return;
    }
    if (!petDetails.age) {
      setError("Pet age is required.");
      return;
    } else if (petDetails.age < 0) {
      setError("Pet age must be a positive number.");
      return;
    }
    if (!petDetails.price) {
      setError("Pet price is required.");
      return;
    } else if (petDetails.price < 0) {
      setError("Pet price must be a positive number.");
      return;
    }
    if (!petDetails.description.trim()) {
      setError("Pet description is required.");
      return;
    }
    if (!petDetails.petImage.trim()) {
      setError("Pet image URL is required.");
      return;
    } 
    console.log('Pet Details:', petDetails);

    axios.post('http://localhost:1414/pets', petDetails, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    })
      .then(response => {
        console.log('Pet added successfully:', response.data);
        toast.success("Pet added Successfully!");
        navigate("/landingAdmin");
      })
      .catch(error => {
        console.error('Error adding pet:', error);
        toast.error("Failed to add pet. Please try again.");
      });
  };

  const handleClick = (e) => {
    e.preventDefault();
    navigate("/landingAdmin");
    window.location.reload();
  };

  return (
    <div>
      <Navbar bg="light" expand="lg" className="mb-4">
        <Navbar.Brand onClick={handleClick}>Home</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
        </Navbar.Collapse>
      </Navbar>
      <h2 className="text-center mb-4">Add New Pet</h2>
      {error && <p className="text-danger text-center">{error}</p>} {/* Display error message */}
      <Form onSubmit={handleSubmit} className="w-50 mx-auto bg-light p-4 rounded shadow-sm">
        <Form.Group controlId="formPetName" className="mb-3">
          <Form.Control
            type="text"
            name="name"
            placeholder="Enter pet's name"
            value={petDetails.name}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formPetBreed" className="mb-3">
          <Form.Control
            type="text"
            name="breed"
            placeholder="Enter pet's breed"
            value={petDetails.breed}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formPetType" className="mb-3">
          <Form.Control
            type="text"
            name="type"
            placeholder="Enter pet's type"
            value={petDetails.type}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Group controlId="formPetAge" className="mb-3">
          <Form.Control
            type="number"
            name="age"
            placeholder="Enter pet's age"
            value={petDetails.age}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formPetPrice" className="mb-3">
          <Form.Control
            type="number"
            name="price"
            placeholder="Enter pet's price"
            value={petDetails.price}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formPetDescription" className="mb-3">
          <Form.Control
            as="textarea"
            name="description"
            placeholder="Enter pet's description"
            value={petDetails.description}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formPetImage" className="mb-3">
          <Form.Control
            type="text"
            name="petImage"
            placeholder="Enter pet's image URL"
            value={petDetails.petImage}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Button variant="primary" type="submit" className="w-100">
          Add Pet
        </Button>
      </Form>
    </div>
  );
};

export default AddPet;