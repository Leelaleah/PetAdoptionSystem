import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Form, Button } from 'react-bootstrap';
import { useParams, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast'; // Import toast

const UpdatePetForm = () => {
  const { petId } = useParams();
  const [petDetails, setPetDetails] = useState(null);
  const [error, setError] = useState(""); // Add error state
  const navigate = useNavigate();
  const token = localStorage.getItem("userToken");

  useEffect(() => {
    axios.get(`http://localhost:1414/pets/${petId}`, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    })
      .then(response => {
        setPetDetails(response.data);
      })
      .catch(error => {
        console.error('Error fetching pet data:', error);
        toast.error('Failed to fetch pet data.'); // Notify user of fetch error
      });
  }, [petId, token]);

  if (!petDetails) return <div>Loading...</div>;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPetDetails({
      ...petDetails,
      [name]: value
    });
    setError(""); // Clear error on input change
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Client-side validation
    if (!petDetails.name.trim()) {
      setError("Pet name is required.");
      return;
    }
    if (!petDetails.breed.trim()) {
      setError("Pet breed is required.");
      return;
    }
    if (!petDetails.age) {
      setError("Pet age is required.");
      return;
    } else if (petDetails.age < 0) {
      setError("Pet age must be a positive number.");
      return;
    }
    if (!petDetails.price) {
      setError("Pet price is required.");
      return;
    } else if (petDetails.price < 0) {
      setError("Pet price must be a positive number.");
      return;
    }
    if (!petDetails.description.trim()) {
      setError("Pet description is required.");
      return;
    }

    axios.put(`http://localhost:1414/pets/${petId}`, petDetails, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    })
      .then(response => {
        console.log('Pet updated successfully:', response.data);
        toast.success('Pet updated successfully!');
        navigate('/landingAdmin');
      })
      .catch(error => {
        console.error('Error updating pet:', error);
        toast.error('Failed to update pet. Please try again.');
      });
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Update Pet Information</h2>
      {error && <p className="text-danger text-center">{error}</p>} {/* Display error message */}
      <Form onSubmit={handleSubmit} className="w-50 mx-auto bg-light p-4 rounded shadow-sm">
        <Form.Group controlId="formPetName" className="mb-3">
          <Form.Control
            type="text"
            name="name"
            placeholder="Enter pet's name"
            value={petDetails.name}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formPetBreed" className="mb-3">
          <Form.Control
            type="text"
            name="breed"
            placeholder="Enter pet's breed"
            value={petDetails.breed}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formPetType" className="mb-3">
          <Form.Control
            type="text"
            name="type"
            placeholder="Enter pet's type"
            value={petDetails.type}
            onChange={handleChange}
            readOnly
          />
        </Form.Group>

        <Form.Group controlId="formPetAge" className="mb-3">
          <Form.Control
            type="number"
            name="age"
            placeholder="Enter pet's age"
            value={petDetails.age}
            onChange={handleChange}
            required
          />
        </Form.Group>

        

        <Form.Group controlId="formPetPrice" className="mb-3">
          <Form.Control
            type="number"
            name="price"
            placeholder="Enter pet's price"
            value={petDetails.price}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Form.Group controlId="formPetDescription" className="mb-3">
          <Form.Control
            as="textarea"
            name="description"
            placeholder="Enter pet's description"
            value={petDetails.description}
            onChange={handleChange}
            required
          />
        </Form.Group>

        <Button variant="primary" type="submit" className="w-100">
          Update Pet
        </Button>
      </Form>
    </div>
  );
};

export default UpdatePetForm;