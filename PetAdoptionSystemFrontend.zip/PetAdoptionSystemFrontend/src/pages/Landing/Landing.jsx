import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { Navbar, Nav, Modal, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../../UserContext';
import AdoptionRequestsList from './AdoptionRequestsList';
import '../Landing/Landing.css';
import toast from 'react-hot-toast';

const Landing = () => {
    const [pets, setPets] = useState([]);
    const [search, setSearch] = useState("");
    const [selectedPet, setSelectedPet] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [showRequests, setShowRequests] = useState(false);
    const [adoptionRequests, setAdoptionRequests] = useState([]);
    const navigate = useNavigate();
    const { userId } = useContext(UserContext);

    useEffect(() => {
        const token = localStorage.getItem("userToken");
        axios.get('http://localhost:1414/pets', {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        })
            .then(response => {
                setPets(response.data);
            })
            .catch(error => {
                console.error('Error fetching pet data:', error);
                toast.error('Failed to fetch pet data.');
            });
    }, []);

    const handleSearchChange = (e) => {
        setSearch(e.target.value);
    };

    const searchPets = (query) => {
        const token = localStorage.getItem("userToken");
        axios.get(`http://localhost:1414/pets/breed/${query}`, {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        })
            .then(response => {
                setPets(response.data || []);
                if (response.data && response.data.length === 0) {
                    toast.error("No pets found with that breed.");
                }
            })
            .catch(error => {
                console.error('Error searching for pets:', error);
                toast.error('Error searching for pets.');
            });
    };

    const handleDetailsClick = (pet) => {
        setSelectedPet(pet);
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setSelectedPet(null);
    };

    const handleAdoptMeClick = (pet) => {
        navigate(`/adoptionrequestform/${pet.id}/${userId}`);
    };

    const handleRequestsClick = () => {
        navigate("/userrequests");
    };

    const handleClick = (e) => {
        e.preventDefault();
        navigate("/landing");
        window.location.reload();
    };

    const handleLogoutClick = () => {
        navigate("/");
    };

    const filteredPets = pets.filter(pet =>
        pet.breed.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div>
            <Navbar bg="light" expand="lg" className="mb-4">
                <Navbar.Brand onClick={handleClick} >Pawfect </Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ml-auto">
                        <Button variant="outline-primary" onClick={handleRequestsClick}>Requests</Button>
                        <Button variant="danger" onClick={handleLogoutClick}>Logout</Button>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>

            <div className="container">
                <h2 className="my-4">All Pets</h2>
                {!showRequests && (
                    <>
                        <input
                            type="text"
                            className="form-control mb-4"
                            placeholder="Search by breed"
                            value={search}
                            onChange={handleSearchChange}
                        />
                        <div className="row">
                            {(search ? (filteredPets.length > 0 ? filteredPets : [{ noPets: true }]) : pets).map((pet, index) => (
                                pet.noPets ? (
                                    <div key="no-pets" className="col-12 text-center">
                                        <p>No pets found.</p>
                                    </div>
                                ) : (
                                    <div key={index} className="col-md-4 mb-4">
                                        <div className="card h-100">
                                            <img src={pet.petImage} alt="Pet Image" className="card-img-top" />
                                            <div className="card-body">
                                                <h5 className="card-title">{pet.name}</h5>
                                                <p className="card-text">
                                                    <small className="text-muted">{pet.breed} | {pet.type}</small><br />
                                                    <small className="text-muted">Age: {pet.age}</small><br />
                                                    <small className="text-muted">Price: {pet.price}</small>
                                                </p>
                                                <div className="d-flex justify-content-between">
                                                    <Button variant="primary" size="sm" onClick={() => handleAdoptMeClick(pet)}>Adopt Me</Button>
                                                    <Button variant="secondary" size="sm" onClick={() => handleDetailsClick(pet)}>Details</Button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            ))}
                        </div>
                    </>
                )}

                {showRequests && (
                    <AdoptionRequestsList userId={userId} adoptionRequests={adoptionRequests} />
                )}

                {selectedPet && (
                    <Modal show={showModal} onHide={handleCloseModal}>
                        <Modal.Header closeButton>
                            <Modal.Title>{selectedPet.name}</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <img src={selectedPet.petImage} alt="Pet Image" className="card-img-top" />
                            <p><strong>Breed:</strong> {selectedPet.breed}</p>
                            <p><strong>Type:</strong> {selectedPet.type}</p>
                            <p><strong>Age:</strong> {selectedPet.age}</p>
                            <p><strong>Price:</strong> {selectedPet.price}</p>
                            <p><strong>More About {selectedPet.name}:</strong> {selectedPet.description}</p>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleCloseModal}>
                                Close
                            </Button>
                        </Modal.Footer>
                    </Modal>
                )}
            </div>
        </div>
    );
};

export default Landing;