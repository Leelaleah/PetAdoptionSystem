import React, { useState, useEffect, useContext } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from 'axios';
import { Modal, Button } from 'react-bootstrap';
import { UserContext } from "../../UserContext";
import toast from "react-hot-toast";

const AdoptionRequestForm = () => {
  const { user } = useContext(UserContext);
  const { petId, userId } = useParams();
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    phoneNumber: "",
    email: "",
    aboutYourself: "",
    status: "Pending",
    petId: petId,
    userId: user.id
  });
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState(""); // Add error state
  const navigate = useNavigate();

  useEffect(() => {
    console.log("petId:", petId, "userId:", userId);
  }, [petId, userId]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError(""); // Clear error on input change
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Client-side validation
    if (!formData.firstname.trim()) {
      setError("First name is required.");
      return;
    }
    if (!formData.lastname.trim()) {
      setError("Last name is required.");
      return;
    }
    if (!formData.phoneNumber.trim()) {
      setError("Phone number is required.");
      return;
    } else if (!/^\+?[1-9]\d{1,14}$/.test(formData.phoneNumber)) {
      setError("Invalid phone number.");
      return;
    }
    if (!formData.email.trim()) {
      setError("Email is required.");
      return;
    } else if (!/^[a-zA-Z0-9._-]+@gmail\.com$/.test(formData.email)) {
      setError("Invalid Gmail format.");
      return;
    }
    if (!formData.aboutYourself.trim()) {
      setError("About yourself is required.");
      return;
    }

    const token = localStorage.getItem("userToken");
    console.log("Adoption Request submitted with:", formData);

    axios.post(`http://localhost:1414/adoption-requests/pet/${petId}/user/${user.id}`, formData, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    })
      .then((response) => {
        console.log("Adoption request successfully submitted:", response.data);
        setShowModal(true);
      })
      .catch((error) => {
        console.error("Error submitting adoption request:", error);
        toast.error("Error submitting adoption request:"); // Notify user if no pets found

      });
  };

  const handleModalClose = () => {
    setShowModal(false);
    navigate("/landing");
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Adoption Request Form</h2>
      {error && <p className="text-danger text-center">{error}</p>} {/* Display error message */}
      <form onSubmit={handleSubmit} className="w-50 mx-auto bg-light p-4 rounded shadow-sm">
        <div className="form-group mb-3">
          <input
            type="text"
            className="form-control"
            name="firstname"
            placeholder="First Name"
            value={formData.firstname}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group mb-3">
          <input
            type="text"
            className="form-control"
            name="lastname"
            placeholder="Last Name"
            value={formData.lastname}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group mb-3">
          <input
            type="tel"
            className="form-control"
            name="phoneNumber"
            placeholder="Phone Number"
            value={formData.phoneNumber}
            onChange={handleChange}
            required
            pattern="^\+?[1-9]\d{1,12}$"
            title="Invalid phone number"
          />
        </div>
        <div className="form-group mb-3">
          <input
            type="email"
            className="form-control"
            name="email"
            placeholder="Email Address"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group mb-3">
          <textarea
            className="form-control"
            name="aboutYourself"
            placeholder="About Yourself"
            value={formData.aboutYourself}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary w-100">Submit</button>
      </form>

      <Modal show={showModal} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>Thank You!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Thank you for your interest! Your adoption request has been submitted successfully.</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleModalClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default AdoptionRequestForm;