import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { Navbar, Nav, Table } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../../UserContext'; 
import "../Landing/UserRequests.css"
import toast from 'react-hot-toast';

const UserRequests = () => {
  const [adoptionRequests, setAdoptionRequests] = useState([]);
  const { user } = useContext(UserContext); 
  const navigate = useNavigate();

  useEffect(() => {
    fetchAdoptionRequests();
  }, [user.id]);

  const fetchAdoptionRequests = () => {
    const token = localStorage.getItem("userToken")
    axios.get(`http://localhost:1414/adoption-requests/user/${user.id}`, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    })
      .then(response => {
        console.log("User's Adoption Requests:", response.data);
        setAdoptionRequests(response.data);
      })
      .catch(error => 
      toast.error("Error fetching adoption requests")); // Notify user if no pets found

  };
  console.log(adoptionRequests)
  const handleHomeClick = () => {
    navigate('/landing');
  };

  return (
    <div>
      <Navbar bg="light" expand="lg" className="mb-4">
        <Navbar.Brand onClick={handleHomeClick}>Home</Navbar.Brand>
      </Navbar>
      <div className="container">
        <h2 className="my-4">Your Adoption Requests</h2>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Pet ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Phone Number</th>
              <th>Email</th>
              <th>About Yourself</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {adoptionRequests.map((request, index) => (
              <tr key={index}>
                <td>{request.petId}</td>
                <td>{request.firstname}</td>
                <td>{request.lastname}</td>
                <td>{request.phoneNumber}</td>
                <td>{request.email}</td>
                <td>{request.aboutYourself}</td>
                <td>{request.status}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default UserRequests;
