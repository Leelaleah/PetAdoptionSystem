import React from 'react';
import { Table } from 'react-bootstrap';

const AdoptionRequestsList = ({ userId, adoptionRequests }) => {
  return (
    <div>
      <h2 className="my-4">Your Adoption Requests</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Pet ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {adoptionRequests.map((request, index) => (
            <tr key={index}>
              <td>{request.petId}</td>
              <td>{request.firstname}</td>
              <td>{request.lastname}</td>
              <td>{request.phoneNumber}</td>
              <td>{request.email}</td>
              <td>{request.status}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default AdoptionRequestsList;
