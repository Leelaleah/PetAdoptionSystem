import { BrowserRouter as Router, Link, Route, Routes } from 'react-router-dom';
import './App.css';
import Home from './pages/Home/Home.jsx';
import Loginn from './pages/Home/Loginn.jsx';
import Register from './pages/Home/Register.jsx';
import Landing from './pages/Landing/Landing.jsx';
import AdoptionRequestsList from './pages/Landing/AdoptionRequestsList.jsx';
import LandingAdmin from './pages/Modification/LandingAdmin.jsx';
import AddPet from './pages/Modification/AddPet.jsx';
import UpdatePetForm from './pages/Modification/UpdatePet.jsx';
import UserRequests from './pages/Landing/UserRequests.jsx';
import AdoptionRequestForm from './pages/Landing/AdoptionRequestForm.jsx';
import AdoptionRequestsListAdmin from './pages/Modification/AdoptionRequestslistAdmin.jsx';
import { Toaster } from 'react-hot-toast';


function App() {

  return (

    <Router>
     <div className='App'>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/loginn' element={<Loginn />} />
          <Route path='/register' element={<Register />} />
          <Route path='/landing' element={<Landing />}/>
          <Route path='/AdoptionRequestsList' element={<AdoptionRequestsList />}/>
          <Route path='/landingAdmin' element={<LandingAdmin />}/>
          <Route path="/addpet" element={<AddPet/>} />
          <Route path="/updatepet/:petId" element={<UpdatePetForm/>} />
          <Route path="/userrequests" element={<UserRequests/>} />
          <Route path="/adoptionrequestform/:petId/:userId" element={<AdoptionRequestForm/>} />
          <Route path="/adoptionrequests/:petId" element={<AdoptionRequestsListAdmin />} /> 

        </Routes>
        
      </div> 
      <Toaster/>
    </Router>

   
  );
}
export default App;
  