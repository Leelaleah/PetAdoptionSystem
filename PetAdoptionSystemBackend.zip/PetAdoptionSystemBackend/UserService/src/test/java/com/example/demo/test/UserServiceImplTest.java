package com.example.demo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserServiceImpl;

 class UserServiceImplTest {

    @Mock
    private UserRepository userRepository; // Mocking the UserRepository dependency

    @InjectMocks
    private UserServiceImpl userService; // Injecting the UserServiceImpl with the mocked dependencies

    @BeforeEach
    public void setUp(){
        // Initialize mocks before each test
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void registerUser() {
        // Create a login request with username and password
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("john");
        loginRequest.setPassword("password");

        // Create a mock user with the same username and password
        User mockUser = new User();
        mockUser.setUsername("john");
        mockUser.setPassword("password");

        // Mock the behavior of userRepository.findByUsername to return the mock user
        when(userRepository.findByUsername("john")).thenReturn(Optional.of(mockUser));

        // Call the loginUser method and assert the returned user's details
        User loggedInUser = userService.loginUser(loginRequest);

        // Verify that the returned user's username and password match the expected values
        assertEquals("john", loggedInUser.getUsername());
        assertEquals("password", loggedInUser.getPassword());
    }
    
    @Test
    void loginUser() {
        // Create a login request with username and password
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("john");
        loginRequest.setPassword("password");

        // Create a mock user with the same username and password
        User mockUser = new User();
        mockUser.setUsername("john");
        mockUser.setPassword("password");

        // Mock the behavior of userRepository.findByUsername to return the mock user
        when(userRepository.findByUsername("john")).thenReturn(Optional.of(mockUser));

        // Call the loginUser method and assert the returned user's details
        User loggedInUser = userService.loginUser(loginRequest);

        // Verify that the returned user's username and password match the expected values
        assertEquals("john", loggedInUser.getUsername());
        assertEquals("password", loggedInUser.getPassword());
    }

    @Test
    void testLoginUserInvalidCredentials() {
        // Create a login request with invalid username and password
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("john");
        loginRequest.setPassword("wrongpassword");

        // Mock the behavior of userRepository.findByUsername to return an empty Optional
        when(userRepository.findByUsername("john")).thenReturn(Optional.empty());

        // Call the loginUser method and assert that it throws an InvalidCredentialsException
        assertThrows(InvalidCredentialsException.class, () -> {
            userService.loginUser(loginRequest);
        });
    }

    @Test
    void testGetUserById() {
        // Create a mock user with an ID
        User mockUser = new User();
        mockUser.setId(1L);
        mockUser.setUsername("john");
        mockUser.setPassword("password");
        mockUser.setEmail("john@example.com");

        // Mock the behavior of userRepository.findById to return the mock user
        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));

        // Call the getUserById method and assert the returned user's details
        User user = userService.getUserById(1L);

        // Verify that the returned user's details match the expected values
        assertEquals(1L, user.getId());
        assertEquals("john", user.getUsername());
        assertEquals("password", user.getPassword());
        assertEquals("john@example.com", user.getEmail());
    }

    @Test
    void testGetUserByIdNotFound() {
        // Mock the behavior of userRepository.findById to return an empty Optional
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        // Call the getUserById method and assert that it throws an IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> {
            userService.getUserById(1L);
        });
    }

    @Test
    void testUpdateUser() {
        // Create a mock user with an ID
        User mockUser = new User();
        mockUser.setId(1L);
        mockUser.setUsername("john");
        mockUser.setPassword("password");
        mockUser.setEmail("john@example.com");

        // Mock the behavior of userRepository.findById to return the mock user
        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));

        // Create an updated user with new details
        User updatedUser = new User();
        updatedUser.setUsername("john_updated");
        updatedUser.setPassword("newpassword");
        updatedUser.setEmail("john_updated@example.com");

        // Mock the behavior of userRepository.save to return the updated user
        when(userRepository.save(mockUser)).thenReturn(mockUser);

        // Call the updateUser method and assert the returned user's details
        User user = userService.updateUser(1L, updatedUser);

        // Verify that the returned user's details match the updated values
        assertEquals("john_updated", user.getUsername());
        assertEquals("newpassword", user.getPassword());
        assertEquals("john_updated@example.com", user.getEmail());
    }
}