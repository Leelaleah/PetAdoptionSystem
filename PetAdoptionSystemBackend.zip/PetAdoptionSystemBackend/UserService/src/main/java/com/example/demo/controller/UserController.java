package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.LoginResponseDto;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;
import com.example.demo.utils.JwtUtils;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/users")
public class UserController {
	@Autowired
    private AuthenticationManager authManager;
    
    @Autowired
    private JwtUtils jwtUtils;
    
    @Autowired
    private UserRepository userRepository;
	
    @Autowired
    private UserService userService; // Injecting the UserService dependency

    @PostMapping("/register")
    public User registerUser(@Valid @RequestBody User user) {
        // Register a new user
        return userService.registerUser(user);
    }

    @PostMapping("/login")
    public LoginResponseDto loginUser(@Valid @RequestBody LoginRequest loginRequest) {
        // Log in a user with the provided credentials

         Authentication authentication = authManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

    	if(authentication.isAuthenticated()	) {
    		
    		User foundUser = userRepository.findByUsername(loginRequest.getUsername()).orElse(null);
    		
    		String token = jwtUtils.generateToken(foundUser.getUsername(), foundUser.getId(), foundUser.getRole());
    		
    		return new LoginResponseDto(token,foundUser.getRole(),foundUser.getId());
    		
    	}else {
    		throw new UsernameNotFoundException("Invalid User Request!!");
    	}
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        // Retrieve a user by their ID
    	System.out.println("false");
        User user = userService.getUserById(id);
        return ResponseEntity.ok(user);
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@Valid @PathVariable Long id, @RequestBody User updatedUser) {
        // Update the details of an existing user
        User user = userService.updateUser(id, updatedUser);
        return ResponseEntity.ok(user);
    }

    @GetMapping("/{id}/adoption-requests")
    public ResponseEntity<List<AdoptionRequestDTO>> getAdoptionRequestsForUser(@PathVariable Long id) {
        // Get adoption requests for a specific user
        List<AdoptionRequestDTO> requests = userService.getAdoptionRequestsForUser(id);
        return ResponseEntity.ok(requests);
    }

    @PostMapping("pet/{petId}/user/{userId}")
    public AdoptionRequestDTO addAdoptionRequest(@Valid @RequestBody AdoptionRequestDTO request, @PathVariable Long petId, @PathVariable Long userId) {
        // Process the adoption request with the new fields
        return userService.addAdoptionRequest(request, petId, userId);
    }

}
