package com.example.demo.model;


public class LoginResponseDto {
	private String jwtToken;
	private String role;
	private Long id;
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	
	public LoginResponseDto() {
		// TODO Auto-generated constructor stub
	}
	public LoginResponseDto(String jwtToken, String role, Long id) {
		super();
		this.jwtToken = jwtToken;
		this.role = role;
		this.id = id;
	}
	
	
	
}
