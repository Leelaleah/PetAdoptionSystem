package com.example.demo.model;


public class LoginRequest {
	private String username;
	private String password;
	private String jwtToken;
	private Long userId;
	
	
	
	

	public LoginRequest(String username, String password, String jwtToken, Long userId) {
		super();
		this.username = username;
		this.password = password;
		this.jwtToken = jwtToken;
		this.userId = userId;
	}

	public String getJwtToken() {
		return jwtToken;
	}

	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	// Getters and setters
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public LoginRequest() {
		// TODO Auto-generated constructor stub
	}
}