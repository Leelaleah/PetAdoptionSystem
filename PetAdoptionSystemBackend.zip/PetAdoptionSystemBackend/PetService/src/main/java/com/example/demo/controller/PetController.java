package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.Pet;
import com.example.demo.service.PetService;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/pets")
public class PetController {

    @Autowired
    private PetService petService; // Injecting the PetService dependency

    @PostMapping
    public Pet addPet(@Valid @RequestBody Pet pet) {
        // Add a new pet
        return petService.addPet(pet);
    }

    @PutMapping("/{id}")
    public Pet updatePet(@Valid @PathVariable Long id, @RequestBody Pet petDetails) {
        // Update an existing pet's details
        return petService.updatePet(id, petDetails);
    }

    @DeleteMapping("/{id}")
    public String deletePet(@PathVariable Long id) {
        // Delete a pet by its ID
        return petService.deletePet(id);
    }

    @GetMapping
    public List<Pet> getAllPets() {
        // Get a list of all pets
        return petService.getAllPets();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pet> getPetById(@PathVariable Long id) {
        // Get a pet by its ID
        Pet pet = petService.getPetById(id);
        return ResponseEntity.ok(pet);
    }

    @GetMapping("/{id}/adoption-requests")
    public ResponseEntity<List<AdoptionRequestDTO>> getAdoptionRequestsForPet(@PathVariable Long id) {
        // Get adoption requests for a specific pet
        List<AdoptionRequestDTO> requests = petService.getAdoptionRequestsForPet(id);
        return ResponseEntity.ok(requests);
    }

    @GetMapping("/breed/{breed}")
    public ResponseEntity<List<Pet>> getPetsByBreed(@PathVariable String breed) {
        // Get a list of pets by their breed
        List<Pet> pets = petService.getPetsByBreed(breed);
        return ResponseEntity.ok(pets);
    }
}