package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.client.AdoptionRequestClient;
import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.exception.NoPetsFoundException;
import com.example.demo.model.AdoptionRequestDTO;
import com.example.demo.model.Pet;
import com.example.demo.repository.PetRepository;

@Service
public class PetServiceImpl implements PetService {

    @Autowired
    private PetRepository petRepository; // Injecting the PetRepository dependency

    @Autowired
    private AdoptionRequestClient adoptionRequestClient; // Injecting the AdoptionRequestClient dependency

    @Override
    public Pet addPet(Pet pet) {
        // Save the pet to the database
        return petRepository.save(pet);
    }


    @Override
    public Pet updatePet(Long id, Pet petDetails) {
        // Find the pet by ID
        Optional<Pet> petOptional = petRepository.findById(id);
        if (petOptional.isPresent()) {
            Pet pet = petOptional.get();
            // Update the pet's details
            pet.setName(petDetails.getName());
            pet.setBreed(petDetails.getBreed());
            pet.setType(petDetails.getType());
            pet.setAge(petDetails.getAge());
            pet.setIsAdopted(petDetails.getIsAdopted());
            pet.setPrice(petDetails.getPrice());
            pet.setDescription(petDetails.getDescription());
            // Save the updated pet to the database
            return petRepository.save(pet);
        } else {
            throw new RuntimeException("Pet not found with id: " + id);
        }
    }

    @Override
    public String deletePet(Long id) {
        // Delete the pet by its ID
        petRepository.deleteById(id);
        return "Pet Deleted Successfully";
    }

    @Override
    public List<Pet> getAllPets() throws InvalidCredentialsException {
        // Get a list of all pets
        return petRepository.findAll();
    }

    @Override
    public Pet getPetById(Long id) throws InvalidCredentialsException {
        // Get a pet by its ID or throw an exception if not found
        return petRepository.findById(id).orElseThrow(() -> new InvalidCredentialsException("Pet not found with id: " + id));
    }

    @Override
    public Pet changeIsAdoptedStatus(Long adoptionId) {
        // Change the adoption status of a pet (implementation not provided)
        return null;
    }

    @Override
    public List<AdoptionRequestDTO> getAdoptionRequestsForPet(Long petId) throws InvalidCredentialsException {
        // Get adoption requests for a specific pet
        return adoptionRequestClient.getRequestsByPetId(petId);
    }

    @Override
    public List<Pet> getPetsByBreed(String breed) {
        List<Pet> pets = petRepository.getPetsByBreed(breed);
        if (pets.isEmpty()) {
            throw new NoPetsFoundException("No pets found for breed: " + breed);
        }
        return pets;
    }
}