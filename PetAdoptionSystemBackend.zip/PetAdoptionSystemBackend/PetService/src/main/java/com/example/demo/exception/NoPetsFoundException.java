package com.example.demo.exception;

public class NoPetsFoundException extends RuntimeException{
	
	public NoPetsFoundException(String msg) {
		super(msg);
	}

}
