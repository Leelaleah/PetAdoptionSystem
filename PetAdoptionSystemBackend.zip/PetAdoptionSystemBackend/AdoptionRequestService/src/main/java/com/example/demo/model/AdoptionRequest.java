package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "adoption_request_table")
public class AdoptionRequest {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique identifier for the adoption request

    @NotNull(message = "Pet ID is mandatory")
    @Column(nullable = false)
    private Long petId; // ID of the pet being adopted

    @NotNull(message = "User ID is mandatory")
    @Column(nullable = false)
    private Long userId; // ID of the user making the adoption request

    @NotBlank(message = "Status is mandatory")
    @Column(nullable = false)
    private String status; // Status of the adoption request (e.g., Pending, Approved, Rejected)
    
    @NotBlank(message = "First name is mandatory")
    @Column(nullable = false)
    private String firstname; // First name of the user

    @NotBlank(message = "Last name is mandatory")
    @Column(nullable = false)
    private String lastname; // Last name of the user

    @NotBlank(message = "Phone number is mandatory")
    @Pattern(regexp = "^\\+?[1-9]\\d{1,14}$", message = "Invalid phone number")
    @Column(nullable = false)
    private String phoneNumber; // Phone number of the user

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Invalid email")
    @Column(nullable = false, unique = true)
    private String email;
    
    


    @NotBlank(message = "About yourself is mandatory")
    @Column(nullable = false)
    private String aboutYourself; 

    
    // Getters and Setters

    public Long getId() {
		return id;
	}

	

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPetId() {
		return petId;
	}

	public void setPetId(Long petId) {
		this.petId = petId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getAboutYourself() {
		return aboutYourself;
	}

	public void setAboutYourself(String aboutYourself) {
		this.aboutYourself = aboutYourself;
	}

	
    
    
 
    
    

    // Constructors
	
	public AdoptionRequest(Long id, @NotNull(message = "Pet ID is mandatory") Long petId,
			@NotNull(message = "User ID is mandatory") Long userId,
			@NotBlank(message = "Status is mandatory") String status,
			
			@NotBlank(message = "Phone number is mandatory") @Pattern(regexp = "^\\+?[1-9]\\d{1,14}$", message = "Invalid phone number") String phoneNumber,
			@NotBlank(message = "Email is mandatory") @Email(message = "Invalid email") String email,
			@NotBlank(message = "First name is mandatory") String firstname,
			@NotBlank(message = "Last name is mandatory") String lastname,
			@NotBlank(message = "About yourself is mandatory") String aboutYourself) {
		super();
		this.id = id;
		this.petId = petId;
		this.userId = userId;
		this.status = status;
		
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.firstname = firstname;
		this.lastname = lastname;
		this.aboutYourself = aboutYourself;
	}

    public AdoptionRequest() {
        // Default constructor
    }
}