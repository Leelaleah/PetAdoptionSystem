package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.InvalidCredentialsException;
import com.example.demo.model.AdoptionRequest;
import com.example.demo.model.AdoptionRequestDto;
import com.example.demo.repository.AdoptionRequestRepository;

@Service
public class AdoptionRequestServiceImpl implements AdoptionRequestService {

    @Autowired
    private AdoptionRequestRepository adoptionRequestRepository; // Injecting the AdoptionRequestRepository dependency
   
 
    
    @Override
    public AdoptionRequest addAdoptionRequest(AdoptionRequest request, Long petId, Long userId) {
        // Set the pet ID and user ID for the adoption request
        request.setPetId(petId);
        request.setUserId(userId);
        // Save the adoption request to the database
        return adoptionRequestRepository.save(request);
    }

    @Override
    public AdoptionRequest updateAdoptionRequest(Long id, AdoptionRequest requestDetails) {
        // Get the existing adoption request by ID
        AdoptionRequest request = getRequestById(id);
        // Update the adoption request's details
        request.setPetId(requestDetails.getPetId());
        request.setUserId(requestDetails.getUserId());
        request.setStatus(requestDetails.getStatus());
        request.setFirstname(requestDetails.getFirstname()); // Add this line
        request.setLastname(requestDetails.getLastname()); // Add this line
        request.setPhoneNumber(requestDetails.getPhoneNumber());
        request.setEmail(requestDetails.getEmail());
        request.setAboutYourself(requestDetails.getAboutYourself()); // Add this line
        // Save the updated adoption request to the database
        return adoptionRequestRepository.save(request);
    }

    @Override
    public void deleteAdoptionRequest(Long id) {
        // Delete the adoption request by its ID
        adoptionRequestRepository.deleteById(id);
    }

    @Override
    public List<AdoptionRequest> getAllRequests() throws InvalidCredentialsException {
        // Get a list of all adoption requests
        return adoptionRequestRepository.findAll();
    }

    @Override
    public List<AdoptionRequest> getRequestsByPetId(Long petId) throws InvalidCredentialsException {
        // Get adoption requests for a specific pet by pet ID
        return adoptionRequestRepository.findByPetId(petId);
    }

    @Override
    public List<AdoptionRequest> getRequestsByUserId(Long userId) throws InvalidCredentialsException {
        // Get adoption requests for a specific user by user ID
        return adoptionRequestRepository.findByUserId(userId);
    }

    @Override
    public AdoptionRequest getRequestById(Long id) throws InvalidCredentialsException {
        // Get an adoption request by its ID or throw an exception if not found
        return adoptionRequestRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Adoption request not found"));
    }

	@Override
	public AdoptionRequestDto updateAdoptionRequestStatus(Long id, String status) {
        Optional<AdoptionRequest> optionalRequest = adoptionRequestRepository.findById(id);
        if (!optionalRequest.isPresent()) {
            throw new RuntimeException("Adoption request not found");
        }
        AdoptionRequest adoptionRequest = optionalRequest.get();
        adoptionRequest.setStatus(status);
        AdoptionRequest updatedRequest = adoptionRequestRepository.save(adoptionRequest);
        return convertToDTO(updatedRequest);
    }

    private AdoptionRequestDto convertToDTO(AdoptionRequest adoptionRequest) {
    	AdoptionRequestDto dto = new AdoptionRequestDto();
        dto.setId(adoptionRequest.getId());
        dto.setPetId(adoptionRequest.getPetId());
        dto.setUserId(adoptionRequest.getUserId());
        dto.setStatus(adoptionRequest.getStatus());
        dto.setFirstname(adoptionRequest.getFirstname());
        dto.setLastname(adoptionRequest.getLastname());
        dto.setEmail(adoptionRequest.getEmail());
        dto.setPhoneNumber(adoptionRequest.getPhoneNumber());
        dto.setAboutYourself(adoptionRequest.getAboutYourself());
		return dto;
    }}