package com.example.demo.model;

public class AdoptionRequestDto {


	private Long id;
	private Long petId;
	private Long userId;
	private String status;
	private String firstname;
    private String lastname;
    private String email;
    private String phoneNumber;
    private String aboutYourself;

	// Getters and setters
	public Long getId() {
		return id;
	}

	public Long getPetId() {
		return petId;
	}

	public void setPetId(Long petId) {
		this.petId = petId;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	 public String getFirstname() {
	        return firstname;
	    }

	    public void setFirstname(String firstname) {
	        this.firstname = firstname;
	    }

	    public String getLastname() {
	        return lastname;
	    }

	    public void setLastname(String lastname) {
	        this.lastname = lastname;
	    }

	    

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getPhoneNumber() {
	        return phoneNumber;
	    }

	    public void setPhoneNumber(String phoneNumber) {
	        this.phoneNumber = phoneNumber;
	    }

	    public String getAboutYourself() {
	        return aboutYourself;
	    }

	    public void setAboutYourself(String aboutYourself) {
	        this.aboutYourself = aboutYourself;
	    }
	
	public AdoptionRequestDto() {
		// TODO Auto-generated constructor stub
	}
}